﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Globalization;
using System.Linq;
using System.Security.Principal;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowsFormsApp1
{
    public partial class Form1 : Form
    {
        private List<account> accounts = new List<account>();
        private account iniAccount = null;

        public Form1()
        {
            InitializeComponent();
            panel_register.Visible = false;
            panel_saldo.Visible = false;
        }

        private void bt_register_Click(object sender, EventArgs e)
        {
            panel_login.Visible = false;
            panel_register.Visible = true;
            panel_deposit.Visible = false;
            panel_saldo.Visible=false;
        }

        private void bt_login_Click(object sender, EventArgs e)
        {
            bool masuk = false;
            foreach (account account in accounts)
            {
                if (account.iniUsername() == tb_usernameLog.Text)
                {
                    if (account.iniPassword() == tb_passwordLog.Text)
                    {
                        masuk = true; 
                        iniAccount = account;
                    }
                    break;
                }
            }
            if (!masuk)
            {
                MessageBox.Show("Username and password not found");
            }
            else
            {
                MessageBox.Show("Login succesful");
                panel_login.Visible = false;
                panel_saldo.Visible = true;
                lb_saldoUtama.Text = iniAccount.iniSaldo().ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
            }
            tb_usernameLog.Clear();
            tb_passwordLog.Clear();

        }

        private void bt_newRegister_Click(object sender, EventArgs e)
        {
            panel_login.Visible = false;
            panel_register.Visible = true;
            bool kedaftar = false;
            foreach (account account in accounts)
            {
                if (account.iniUsername() == ((Control)tb_usernameReg).Text)
                {
                    kedaftar = true;
                    break;
                }
            }
            if (kedaftar)
            {
                MessageBox.Show("Username has been used");
                tb_usernameReg.Clear();
                tb_passwordReg.Clear();
            }
            else
            {
                accounts.Add(new account(((Control)tb_usernameReg).Text, ((Control)tb_passwordReg).Text, 0L));
                MessageBox.Show("Register succesful");
                panel_login.Visible = true;
                panel_register.Visible = false;
            }
            tb_passwordReg.Clear();
            tb_usernameReg.Clear();
        }

        private void bt_deposit_Click(object sender, EventArgs e)
        {
            panel_deposit.Visible = true;
            panel_saldo.Visible = false;
        }

        private void bt_inputDeposit_Click(object sender, EventArgs e)
        {
            long deposit = Convert.ToInt64((tb_inputDeposit).Text);
            if (deposit < 1)
            {
                MessageBox.Show("Deposit amount can't be less than 1");
            }
            else
            {
                iniAccount.Saldo(deposit, 1);
                MessageBox.Show("Succesfully add deposit");
            }
            tb_inputDeposit.Clear();
            panel_deposit.Visible = false;
            panel_saldo.Visible = true;
            lb_saldoUtama.Text = iniAccount.iniSaldo().ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
        }

        private void panel_saldo_Paint(object sender, PaintEventArgs e)
        {

        }

        private void panel_register_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void bt_logout_Click(object sender, EventArgs e)
        {
            panel_login.Visible = true;
            panel_saldo.Visible=false;
        }

        private void bt_inputWithdraw_Click(object sender, EventArgs e)
        {
            long withdraw = Convert.ToInt64((tb_inputWithdraw).Text);
            if (withdraw < 1)
            {
                MessageBox.Show("Withdraw amount can't be less than 1");
            }
            else if (iniAccount.iniSaldo() - withdraw < 0)
            {
                MessageBox.Show("Withdraw failed. not enough balance.");
            }
            else
            {
                iniAccount.Saldo(withdraw, 2);
                MessageBox.Show("Succesfully withdraw");
                panel_withdraw.Visible = false;
                panel_saldo.Visible = true; 
            }
            tb_inputWithdraw.Clear();
            lb_saldoUtama.Text = iniAccount.iniSaldo().ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));
        }

        private void bt_logoutWith_Click (object sender, EventArgs e)
        {
            panel_withdraw.Visible = false;
            panel_saldo.Visible = false;
            panel_login.Visible = true;
        }

        private void bt_logoutDep_Click(object sender, EventArgs e)
        {
            panel_deposit.Visible = false;
            panel_saldo.Visible = false;
            panel_login.Visible = true;
        }

        private void bt_withdraw_Click(object sender, EventArgs e)
        {
            panel_withdraw.Visible = true;
            panel_saldo.Visible = false;
            lb_saldoUtama2.Text = iniAccount.iniSaldo().ToString("C", CultureInfo.CreateSpecificCulture("id-ID"));

        }

        private void lb_saldoUtama_Click(object sender, EventArgs e)
        {

        }
    }
}
