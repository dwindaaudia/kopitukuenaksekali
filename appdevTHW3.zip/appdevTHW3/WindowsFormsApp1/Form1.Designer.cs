﻿namespace WindowsFormsApp1
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lb_ucBank = new System.Windows.Forms.Label();
            this.lb_username = new System.Windows.Forms.Label();
            this.lb_password = new System.Windows.Forms.Label();
            this.tb_usernameLog = new System.Windows.Forms.TextBox();
            this.tb_passwordLog = new System.Windows.Forms.TextBox();
            this.bt_login = new System.Windows.Forms.Button();
            this.bt_register = new System.Windows.Forms.Button();
            this.panel_login = new System.Windows.Forms.Panel();
            this.panel_register = new System.Windows.Forms.Panel();
            this.bt_newRegister = new System.Windows.Forms.Button();
            this.tb_passwordReg = new System.Windows.Forms.TextBox();
            this.tb_usernameReg = new System.Windows.Forms.TextBox();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.panel_saldo = new System.Windows.Forms.Panel();
            this.bt_logout = new System.Windows.Forms.Button();
            this.bt_withdraw = new System.Windows.Forms.Button();
            this.bt_deposit = new System.Windows.Forms.Button();
            this.lb_saldoUtama = new System.Windows.Forms.Label();
            this.lb_balance = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.panel_deposit = new System.Windows.Forms.Panel();
            this.tb_inputDeposit = new System.Windows.Forms.TextBox();
            this.bt_logoutDep = new System.Windows.Forms.Button();
            this.bt_inputDeposit = new System.Windows.Forms.Button();
            this.label5 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.panel_withdraw = new System.Windows.Forms.Panel();
            this.lb_saldoUtama2 = new System.Windows.Forms.Label();
            this.lb_balanceWithdraw = new System.Windows.Forms.Label();
            this.tb_inputWithdraw = new System.Windows.Forms.TextBox();
            this.bt_logoutWith = new System.Windows.Forms.Button();
            this.bt_inputWithdraw = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.panel_login.SuspendLayout();
            this.panel_register.SuspendLayout();
            this.panel_saldo.SuspendLayout();
            this.panel_deposit.SuspendLayout();
            this.panel_withdraw.SuspendLayout();
            this.SuspendLayout();
            // 
            // lb_ucBank
            // 
            this.lb_ucBank.AutoSize = true;
            this.lb_ucBank.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_ucBank.Location = new System.Drawing.Point(9, 23);
            this.lb_ucBank.Name = "lb_ucBank";
            this.lb_ucBank.Size = new System.Drawing.Size(204, 52);
            this.lb_ucBank.TabIndex = 0;
            this.lb_ucBank.Text = "UC Bank";
            // 
            // lb_username
            // 
            this.lb_username.AutoSize = true;
            this.lb_username.Location = new System.Drawing.Point(14, 109);
            this.lb_username.Name = "lb_username";
            this.lb_username.Size = new System.Drawing.Size(95, 20);
            this.lb_username.TabIndex = 1;
            this.lb_username.Text = "Username : ";
            // 
            // lb_password
            // 
            this.lb_password.AutoSize = true;
            this.lb_password.Location = new System.Drawing.Point(14, 149);
            this.lb_password.Name = "lb_password";
            this.lb_password.Size = new System.Drawing.Size(90, 20);
            this.lb_password.TabIndex = 2;
            this.lb_password.Text = "Password : ";
            // 
            // tb_usernameLog
            // 
            this.tb_usernameLog.Location = new System.Drawing.Point(115, 103);
            this.tb_usernameLog.Name = "tb_usernameLog";
            this.tb_usernameLog.Size = new System.Drawing.Size(174, 26);
            this.tb_usernameLog.TabIndex = 3;
            // 
            // tb_passwordLog
            // 
            this.tb_passwordLog.Location = new System.Drawing.Point(115, 143);
            this.tb_passwordLog.Name = "tb_passwordLog";
            this.tb_passwordLog.Size = new System.Drawing.Size(174, 26);
            this.tb_passwordLog.TabIndex = 4;
            // 
            // bt_login
            // 
            this.bt_login.Location = new System.Drawing.Point(115, 200);
            this.bt_login.Name = "bt_login";
            this.bt_login.Size = new System.Drawing.Size(121, 39);
            this.bt_login.TabIndex = 5;
            this.bt_login.Text = "Login";
            this.bt_login.UseVisualStyleBackColor = true;
            this.bt_login.Click += new System.EventHandler(this.bt_login_Click);
            // 
            // bt_register
            // 
            this.bt_register.Location = new System.Drawing.Point(115, 245);
            this.bt_register.Name = "bt_register";
            this.bt_register.Size = new System.Drawing.Size(121, 39);
            this.bt_register.TabIndex = 6;
            this.bt_register.Text = "Register";
            this.bt_register.UseVisualStyleBackColor = true;
            this.bt_register.Click += new System.EventHandler(this.bt_register_Click);
            // 
            // panel_login
            // 
            this.panel_login.Controls.Add(this.bt_register);
            this.panel_login.Controls.Add(this.bt_login);
            this.panel_login.Controls.Add(this.tb_passwordLog);
            this.panel_login.Controls.Add(this.tb_usernameLog);
            this.panel_login.Controls.Add(this.lb_password);
            this.panel_login.Controls.Add(this.lb_username);
            this.panel_login.Controls.Add(this.lb_ucBank);
            this.panel_login.Location = new System.Drawing.Point(472, 78);
            this.panel_login.Name = "panel_login";
            this.panel_login.Size = new System.Drawing.Size(349, 294);
            this.panel_login.TabIndex = 7;
            // 
            // panel_register
            // 
            this.panel_register.Controls.Add(this.bt_newRegister);
            this.panel_register.Controls.Add(this.tb_passwordReg);
            this.panel_register.Controls.Add(this.tb_usernameReg);
            this.panel_register.Controls.Add(this.label1);
            this.panel_register.Controls.Add(this.label2);
            this.panel_register.Controls.Add(this.label3);
            this.panel_register.Location = new System.Drawing.Point(498, 63);
            this.panel_register.Name = "panel_register";
            this.panel_register.Size = new System.Drawing.Size(323, 294);
            this.panel_register.TabIndex = 8;
            this.panel_register.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_register_Paint);
            // 
            // bt_newRegister
            // 
            this.bt_newRegister.Location = new System.Drawing.Point(125, 204);
            this.bt_newRegister.Name = "bt_newRegister";
            this.bt_newRegister.Size = new System.Drawing.Size(121, 39);
            this.bt_newRegister.TabIndex = 6;
            this.bt_newRegister.Text = "Register";
            this.bt_newRegister.UseVisualStyleBackColor = true;
            this.bt_newRegister.Click += new System.EventHandler(this.bt_newRegister_Click);
            // 
            // tb_passwordReg
            // 
            this.tb_passwordReg.Location = new System.Drawing.Point(125, 143);
            this.tb_passwordReg.Name = "tb_passwordReg";
            this.tb_passwordReg.Size = new System.Drawing.Size(174, 26);
            this.tb_passwordReg.TabIndex = 4;
            // 
            // tb_usernameReg
            // 
            this.tb_usernameReg.Location = new System.Drawing.Point(125, 103);
            this.tb_usernameReg.Name = "tb_usernameReg";
            this.tb_usernameReg.Size = new System.Drawing.Size(174, 26);
            this.tb_usernameReg.TabIndex = 3;
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(24, 149);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(90, 20);
            this.label1.TabIndex = 2;
            this.label1.Text = "Password : ";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(24, 109);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(95, 20);
            this.label2.TabIndex = 1;
            this.label2.Text = "Username : ";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label3.Location = new System.Drawing.Point(19, 23);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(204, 52);
            this.label3.TabIndex = 0;
            this.label3.Text = "UC Bank";
            // 
            // panel_saldo
            // 
            this.panel_saldo.Controls.Add(this.bt_logout);
            this.panel_saldo.Controls.Add(this.bt_withdraw);
            this.panel_saldo.Controls.Add(this.bt_deposit);
            this.panel_saldo.Controls.Add(this.lb_saldoUtama);
            this.panel_saldo.Controls.Add(this.lb_balance);
            this.panel_saldo.Controls.Add(this.label6);
            this.panel_saldo.Location = new System.Drawing.Point(513, 63);
            this.panel_saldo.Name = "panel_saldo";
            this.panel_saldo.Size = new System.Drawing.Size(348, 305);
            this.panel_saldo.TabIndex = 8;
            this.panel_saldo.Paint += new System.Windows.Forms.PaintEventHandler(this.panel_saldo_Paint);
            // 
            // bt_logout
            // 
            this.bt_logout.Location = new System.Drawing.Point(215, 85);
            this.bt_logout.Name = "bt_logout";
            this.bt_logout.Size = new System.Drawing.Size(121, 39);
            this.bt_logout.TabIndex = 7;
            this.bt_logout.Text = "Log Out";
            this.bt_logout.UseVisualStyleBackColor = true;
            this.bt_logout.Click += new System.EventHandler(this.bt_logout_Click);
            // 
            // bt_withdraw
            // 
            this.bt_withdraw.Location = new System.Drawing.Point(113, 245);
            this.bt_withdraw.Name = "bt_withdraw";
            this.bt_withdraw.Size = new System.Drawing.Size(121, 39);
            this.bt_withdraw.TabIndex = 6;
            this.bt_withdraw.Text = "Withdraw";
            this.bt_withdraw.UseVisualStyleBackColor = true;
            this.bt_withdraw.Click += new System.EventHandler(this.bt_withdraw_Click);
            // 
            // bt_deposit
            // 
            this.bt_deposit.Location = new System.Drawing.Point(113, 200);
            this.bt_deposit.Name = "bt_deposit";
            this.bt_deposit.Size = new System.Drawing.Size(121, 39);
            this.bt_deposit.TabIndex = 5;
            this.bt_deposit.Text = "Deposit";
            this.bt_deposit.UseVisualStyleBackColor = true;
            this.bt_deposit.Click += new System.EventHandler(this.bt_deposit_Click);
            // 
            // lb_saldoUtama
            // 
            this.lb_saldoUtama.AutoSize = true;
            this.lb_saldoUtama.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_saldoUtama.Location = new System.Drawing.Point(122, 140);
            this.lb_saldoUtama.Name = "lb_saldoUtama";
            this.lb_saldoUtama.Size = new System.Drawing.Size(112, 32);
            this.lb_saldoUtama.TabIndex = 2;
            this.lb_saldoUtama.Text = "Rp0,00";
            this.lb_saldoUtama.Click += new System.EventHandler(this.lb_saldoUtama_Click);
            // 
            // lb_balance
            // 
            this.lb_balance.AutoSize = true;
            this.lb_balance.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_balance.Location = new System.Drawing.Point(17, 145);
            this.lb_balance.Name = "lb_balance";
            this.lb_balance.Size = new System.Drawing.Size(80, 22);
            this.lb_balance.TabIndex = 1;
            this.lb_balance.Text = "Balance ";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label6.Location = new System.Drawing.Point(7, 23);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(204, 52);
            this.label6.TabIndex = 0;
            this.label6.Text = "UC Bank";
            // 
            // panel_deposit
            // 
            this.panel_deposit.Controls.Add(this.tb_inputDeposit);
            this.panel_deposit.Controls.Add(this.bt_logoutDep);
            this.panel_deposit.Controls.Add(this.bt_inputDeposit);
            this.panel_deposit.Controls.Add(this.label5);
            this.panel_deposit.Controls.Add(this.label7);
            this.panel_deposit.Location = new System.Drawing.Point(522, 55);
            this.panel_deposit.Name = "panel_deposit";
            this.panel_deposit.Size = new System.Drawing.Size(323, 305);
            this.panel_deposit.TabIndex = 9;
            this.panel_deposit.Visible = false;
            // 
            // tb_inputDeposit
            // 
            this.tb_inputDeposit.Location = new System.Drawing.Point(80, 173);
            this.tb_inputDeposit.Name = "tb_inputDeposit";
            this.tb_inputDeposit.Size = new System.Drawing.Size(169, 26);
            this.tb_inputDeposit.TabIndex = 8;
            // 
            // bt_logoutDep
            // 
            this.bt_logoutDep.Location = new System.Drawing.Point(178, 86);
            this.bt_logoutDep.Name = "bt_logoutDep";
            this.bt_logoutDep.Size = new System.Drawing.Size(121, 39);
            this.bt_logoutDep.TabIndex = 7;
            this.bt_logoutDep.Text = "Log Out";
            this.bt_logoutDep.UseVisualStyleBackColor = true;
            this.bt_logoutDep.Click += new System.EventHandler(this.bt_logoutDep_Click);
            // 
            // bt_inputDeposit
            // 
            this.bt_inputDeposit.Location = new System.Drawing.Point(102, 223);
            this.bt_inputDeposit.Name = "bt_inputDeposit";
            this.bt_inputDeposit.Size = new System.Drawing.Size(121, 39);
            this.bt_inputDeposit.TabIndex = 5;
            this.bt_inputDeposit.Text = "Deposit";
            this.bt_inputDeposit.UseVisualStyleBackColor = true;
            this.bt_inputDeposit.Click += new System.EventHandler(this.bt_inputDeposit_Click);
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label5.Location = new System.Drawing.Point(85, 143);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(160, 20);
            this.label5.TabIndex = 1;
            this.label5.Text = "Input deposit amount";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label7.Location = new System.Drawing.Point(19, 23);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(204, 52);
            this.label7.TabIndex = 0;
            this.label7.Text = "UC Bank";
            // 
            // panel_withdraw
            // 
            this.panel_withdraw.Controls.Add(this.lb_saldoUtama2);
            this.panel_withdraw.Controls.Add(this.lb_balanceWithdraw);
            this.panel_withdraw.Controls.Add(this.tb_inputWithdraw);
            this.panel_withdraw.Controls.Add(this.bt_logoutWith);
            this.panel_withdraw.Controls.Add(this.bt_inputWithdraw);
            this.panel_withdraw.Controls.Add(this.label4);
            this.panel_withdraw.Controls.Add(this.label8);
            this.panel_withdraw.Location = new System.Drawing.Point(534, 52);
            this.panel_withdraw.Name = "panel_withdraw";
            this.panel_withdraw.Size = new System.Drawing.Size(406, 305);
            this.panel_withdraw.TabIndex = 10;
            this.panel_withdraw.Visible = false;
            // 
            // lb_saldoUtama2
            // 
            this.lb_saldoUtama2.AutoSize = true;
            this.lb_saldoUtama2.Font = new System.Drawing.Font("Microsoft Sans Serif", 14F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_saldoUtama2.Location = new System.Drawing.Point(124, 133);
            this.lb_saldoUtama2.Name = "lb_saldoUtama2";
            this.lb_saldoUtama2.Size = new System.Drawing.Size(112, 32);
            this.lb_saldoUtama2.TabIndex = 10;
            this.lb_saldoUtama2.Text = "Rp0,00";
            // 
            // lb_balanceWithdraw
            // 
            this.lb_balanceWithdraw.AutoSize = true;
            this.lb_balanceWithdraw.Font = new System.Drawing.Font("Microsoft Sans Serif", 9F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lb_balanceWithdraw.Location = new System.Drawing.Point(41, 141);
            this.lb_balanceWithdraw.Name = "lb_balanceWithdraw";
            this.lb_balanceWithdraw.Size = new System.Drawing.Size(80, 22);
            this.lb_balanceWithdraw.TabIndex = 9;
            this.lb_balanceWithdraw.Text = "Balance ";
            // 
            // tb_inputWithdraw
            // 
            this.tb_inputWithdraw.Location = new System.Drawing.Point(73, 213);
            this.tb_inputWithdraw.Name = "tb_inputWithdraw";
            this.tb_inputWithdraw.Size = new System.Drawing.Size(169, 26);
            this.tb_inputWithdraw.TabIndex = 8;
            // 
            // bt_logoutWith
            // 
            this.bt_logoutWith.Location = new System.Drawing.Point(178, 86);
            this.bt_logoutWith.Name = "bt_logoutWith";
            this.bt_logoutWith.Size = new System.Drawing.Size(121, 39);
            this.bt_logoutWith.TabIndex = 7;
            this.bt_logoutWith.Text = "Log Out";
            this.bt_logoutWith.UseVisualStyleBackColor = true;
            this.bt_logoutWith.Click += new System.EventHandler(this.bt_logoutWith_Click);
            // 
            // bt_inputWithdraw
            // 
            this.bt_inputWithdraw.Location = new System.Drawing.Point(102, 245);
            this.bt_inputWithdraw.Name = "bt_inputWithdraw";
            this.bt_inputWithdraw.Size = new System.Drawing.Size(121, 39);
            this.bt_inputWithdraw.TabIndex = 5;
            this.bt_inputWithdraw.Text = "Withdraw";
            this.bt_inputWithdraw.UseVisualStyleBackColor = true;
            this.bt_inputWithdraw.Click += new System.EventHandler(this.bt_inputWithdraw_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Font = new System.Drawing.Font("Microsoft Sans Serif", 8F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label4.Location = new System.Drawing.Point(78, 183);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(170, 20);
            this.label4.TabIndex = 1;
            this.label4.Text = "Input withdraw amount";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Font = new System.Drawing.Font("Microsoft Sans Serif", 22F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label8.Location = new System.Drawing.Point(19, 23);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(204, 52);
            this.label8.TabIndex = 0;
            this.label8.Text = "UC Bank";
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 20F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1234, 730);
            this.Controls.Add(this.panel_register);
            this.Controls.Add(this.panel_deposit);
            this.Controls.Add(this.panel_login);
            this.Controls.Add(this.panel_saldo);
            this.Controls.Add(this.panel_withdraw);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.panel_login.ResumeLayout(false);
            this.panel_login.PerformLayout();
            this.panel_register.ResumeLayout(false);
            this.panel_register.PerformLayout();
            this.panel_saldo.ResumeLayout(false);
            this.panel_saldo.PerformLayout();
            this.panel_deposit.ResumeLayout(false);
            this.panel_deposit.PerformLayout();
            this.panel_withdraw.ResumeLayout(false);
            this.panel_withdraw.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lb_ucBank;
        private System.Windows.Forms.Label lb_username;
        private System.Windows.Forms.Label lb_password;
        private System.Windows.Forms.TextBox tb_usernameLog;
        private System.Windows.Forms.TextBox tb_passwordLog;
        private System.Windows.Forms.Button bt_login;
        private System.Windows.Forms.Button bt_register;
        private System.Windows.Forms.Panel panel_login;
        private System.Windows.Forms.Panel panel_register;
        private System.Windows.Forms.Button bt_newRegister;
        private System.Windows.Forms.TextBox tb_passwordReg;
        private System.Windows.Forms.TextBox tb_usernameReg;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Panel panel_saldo;
        private System.Windows.Forms.Button bt_logout;
        private System.Windows.Forms.Button bt_withdraw;
        private System.Windows.Forms.Button bt_deposit;
        private System.Windows.Forms.Label lb_saldoUtama;
        private System.Windows.Forms.Label lb_balance;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Panel panel_deposit;
        private System.Windows.Forms.Button bt_logoutDep;
        private System.Windows.Forms.Button bt_inputDeposit;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.TextBox tb_inputDeposit;
        private System.Windows.Forms.Panel panel_withdraw;
        private System.Windows.Forms.TextBox tb_inputWithdraw;
        private System.Windows.Forms.Button bt_logoutWith;
        private System.Windows.Forms.Button bt_inputWithdraw;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label lb_saldoUtama2;
        private System.Windows.Forms.Label lb_balanceWithdraw;
    }
}

