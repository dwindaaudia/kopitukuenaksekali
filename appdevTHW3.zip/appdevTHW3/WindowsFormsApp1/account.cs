﻿


internal class account
{
    private string username;
    private string password;
    private long saldo;

    public account(string username, string password, long saldo)
    {
        this.username = username;
        this.password = password;
        this.saldo = saldo;
    }

    public void usernameBaru (string username)
    {
        this.username = username;
    }

    public string iniUsername()
    {
        return username;
    }

    public void passwordBaru (string password)
    {
        this.password = password;
    }

    public string iniPassword()
    {
        return password;
    }

    public void Saldo (long saldo, int klik)
    {
        if (klik == 1)
        {
            this.saldo += saldo;
        }
        if (klik == 2)
        {
            this.saldo -= saldo;
        }
    }

    public long iniSaldo()
    {
        return saldo;
    }
}
